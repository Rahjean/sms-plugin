<script>

    function showCollabClient() {
        // console.log(listeoStats.post_id) ;
        var listing_id = listeoStats.post_id ;
        $.ajax({
            type: "POST",
            url:  "/wp-content/plugins/jm-collaborateur/Controller/getData.php",
            dataType: 'json',
            data: { "listing_id": listing_id } ,
            
            success: function(data) {

                $('#listing-overview').after('<form id="collabShow" style="padding:10px; box-shadow: 0px 1px 16px -2px grey ; border-radius: 10px;" ><h3 style="color:#73cdce;font-weight:bold !important;">Nos Collaborateurs</h3></form>');

                // console.log(data) ;
                data.forEach(element => {
                    console.log(element['annonce_meta']) ;
                    var jsonCollab = JSON.parse(element['annonce_meta']) ;
                    
                    Object.entries(jsonCollab).forEach(([key, value]) => {
                        // console.log(key + ' - ' + value)
                        
                        if ( key.includes('collab_input_num_') ) {
                            if ($('.booking-widget').length > 0) {
                                console.log('oui');
                                var html = '<div class="row"><div class="col-md-11"><input class="form-control colab_class" type="text" name="'+key+'" value="'+value+'" disabled></div> <div class="col-md-1"><input class="form-check-input check_collab" type="checkbox"></div></div>' ;
                            }
                            else{
                                console.log('non');
                                var html = '<div class="row"><div class="col-md-11"><input class="form-control colab_class" type="text" name="'+key+'" value="'+value+'" disabled></div>' ;
                            }
                           
                            $('#collabShow').append(html) ;
                        }
                    })
                });

            },

        });
    }
   
    showCollabClient() ;


</script>


