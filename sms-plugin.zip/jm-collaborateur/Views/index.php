<!doctype html>
<html lang="en">
 
<head>
    <link rel="stylesheet" href=
"//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href=
"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
 
    <style>
        body {
            display: flex;
            flex-direction: column;
            margin-top: 1%;
            justify-content: center;
            align-items: center;
        }
 
        #rowAdder {
            margin-left: 17px;
        }
    </style>
</head>
 
<body>
 
    <div>
 
        <form id="collab">
            <div class="">
                <div class="col-lg-12">
                    <div id="row">
                        <!-- <div class="input-group m-3">
                            <div class="input-group-prepend">
                                <button class="btn btn-danger"
                                    id="DeleteRow" type="button">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                            <input type="text"
                                class="form-control m-input">
                        </div> -->
                    </div>
 
                    <div id="newinput"></div>
                    <button id="rowAdder" type="button"
                        class="btn btn-dark">
                        <span class="bi bi-plus-square-dotted">
                        </span> Ajouter
                    </button>
                </div>
            </div>
        </form>
    </div>

</body>
 <!-- <span id="colbBtn" >collab</span> -->
</html>


<!-- <span class="clickSms"> sms</span> -->
