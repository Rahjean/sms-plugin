<?php

define( 'SHORTINIT', true );
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

global $wpdb;

$table_name = $wpdb->prefix . 'sms_data_collaborateur_booking_jm';

$meta_booking        = json_decode($_POST['dataBooking']);
$meta_booking_encode = json_encode($_POST['dataBooking']);
// var_dump($meta_booking);
$user_id    = $meta_booking[0]->value ;
$listing_id = $meta_booking[1]->value ;
$dateFinal  = $meta_booking[2]->value ;
$phone      = $meta_booking[3]->value ;

$wpdb->insert( $table_name , array(
    "id_annonce" => $listing_id,
    "id_user" => $user_id,
    "dateFinal" => $dateFinal,
    "phone" => $phone,
    'booking_meta' => $_POST['dataBooking']
));

 
?>