<?php session_start(); ?>
<input type="hidden" name="userId" id="userId" value="<?= $_SESSION['userId'] ?>" >