$(document).ready(function() {

  function collab() {

      if ( window.location.href.indexOf("action=edit") > -1) {
        
        setTimeout(() => {
          const reversedKeys = Object.keys(localStorage).reverse();
          reversedKeys.forEach(key => {
            if ( key.includes('collab_input_num_') ) {
              var html = '<input class="form-control colab_class" type="text" name="'+key+'" value="'+localStorage[key]+'" > ' ;
              $('#collabShow').append(html) ;
            }
          });
        }, 1000);

      }
      else {

        var html_Collab = "<form id='load_collab'><h2>Collaborateur</h2><span id='saveData' >collab</span></form>";

        $('.listing_preview_container').append(html_Collab) ;
  
        const reversedKeys = Object.keys(localStorage).reverse();
  
        reversedKeys.forEach(key => {
  
          if ( key.includes('collab_input_num_') ) {
            var html = '<input class="form-control colab_class" type="text" name="'+key+'" value="'+localStorage[key]+'">' ;
            $('#load_collab').append(html) ;
          }
  
        });

      }
    
      $.get( "/wp-content/plugins/jm-collaborateur/Views/index.php", function( data ) {

          $( ".form-field-tax-listing_feature-container" ).append( data );

          $("#rowAdder").click(function () {
            if( $( "#collab input" ).last()[0] != null ){
              var lastInput = $( "#collab input" ).last()[0].name ;
            }else {
              var lastInput = "collab_input_num_0" ;
            }
            var lastNum = lastInput.split("_").pop();
            var numNext = parseInt(lastNum);
            var finalNextNum = numNext+1 ;

            //  $('[name=submit_listing]').prop('disabled', 'true') ;
            
              newRowAdd =
              '<div id="row"> <div class="input-group m-3">' +
              '<div class="input-group-prepend">' +
              '<button class="btn btn-danger" id="DeleteRow" type="button">' +
              '<i class="bi bi-trash"></i></button> </div>' +
              '<input type="text" class="form-control m-input collab_input" name="collab_input_num_'+ finalNextNum +'" required> </div> </div>';

              $('#newinput').append(newRowAdd);
              // console.log(finalNextNum) ;
          });

          $("body").on("click", "#DeleteRow", function () {
              $(this).parents("#row").remove();
          })

          $('[name=submit_listing]').on('click', function(){
          // $('#colbBtn').on('click', function(){
            
            if ( window.location.href.indexOf("action=edit") > -1) {
             
              var x = $("#collab").serializeArray();
              for (let index = 0; index < x.length; index++) {
                const element = x[index];
                localStorage.setItem(element.name,element.value ) ;
              }
              
            }
            else {
              var x = $("#collab").serializeArray();
     
              for (let index = 0; index < x.length; index++) {
                const element = x[index];
                localStorage.setItem(element.name,element.value ) ;
                var html = '<input class="form-control colab_class" type="text" name="'+element.name+'" value="'+localStorage.getItem(element.name)+'">' ;
                $('#load_collab').append(html) ;
              }

            }

          })

      });
        
      // ###### affichage collaborateur pour client
      $.get( "/wp-content/plugins/jm-collaborateur/Views/client-show.php", function( data ) {

        $( "#listing-overview" ).append( data );
      
        // ####### JM MODIFE DEBUT ##########

          setTimeout(() => {
            // console.log('###### loader #########') ;

            if ( window.location.href.indexOf("/my-listings/?status=active") > -1) {
              localStorage.clear() ;
            }

            var click_s=0;
            $('.check_collab').on('click', function(){

              if(click_s % 2 == 0){
                
                if( $(this)[0].checked == true ) {
                  var name = $(this).closest('.row').find('input')[0].name;
                  var value = $(this).closest('.row').find('input')[0].value;
                  // console.log('oui 1', $(this)[0].checked , name ) ;
                  var inputAppend = '<input class="'+name+'" type="hidden" name="'+name+'" value="'+value+'">' ;
                  $('#collabShow').append(inputAppend) ;
                }else {
                  var name = $(this).closest('.row').find('input')[0].name;
                  // console.log( 'non 1', $(this)[0].checked , name) ;
                  $('#collabShow').find('.'+name+'').remove() ;
                  localStorage.removeItem(name);
                }
              }
              else{
                if( $(this)[0].checked == false ) {
                  var name = $(this).closest('.row').find('input')[0].name;
                  // console.log('non 2', $(this)[0].checked , name) ;
                  $('#collabShow').find('.'+name+'').remove() ;
                  localStorage.removeItem(name);
                }else {
                  var name = $(this).closest('.row').find('input')[0].name;
                  var value = $(this).closest('.row').find('input')[0].value;
                  // console.log('oui 2', $(this)[0].checked , name) ;
                  var inputAppend = '<input class="'+name+'" type="hidden" name="'+name+'" value="'+value+'">' ;
                  $('#collabShow').append(inputAppend) ;
                }
              }

              click_s++;
            })

          }, 3000);


          // ######## save Data collab Booking  ########
          if (window.location.href.indexOf("booking-confirmation") > -1) {

              $.get( "/wp-content/plugins/jm-collaborateur/Controller/userData.php", function( data ) {
                $('#booking-confirmation').append( data );
              })
             
              $('.booking-confirmation-btn').on('click', function(){

                var userId      = $('#userId').val() ;
                var listing_id  = $('#listing_id').val() ;
                var date        = $('#booking-confirmation-summary-date span')[0].innerText ;
                var myarr = date.split("-");
                var heureReserved = $('#booking-confirmation-summary-time span')[0].innerText ;
                var heureReservedFinal = heureReserved.replace(":", "h");

                var phone        = $('[name=phone]').val()
      
                if( myarr[1] == "01"){
                  var dateN  = myarr[2]+" janvier "+myarr[0] ;
                }
                if( myarr[1] == "02"){
                  var dateN  = myarr[2]+" février "+myarr[0] ;
                }
                if( myarr[1] == "03"){
                  var dateN  = myarr[2]+" mars "+myarr[0] ;
                }
                if( myarr[1] == "04"){
                  var dateN  = myarr[2]+" avril "+myarr[0] ;
                }
                if( myarr[1] == "05"){
                  var dateN  = myarr[2]+" mai "+myarr[0] ;
                }
                if( myarr[1] == "06"){
                  var dateN  = myarr[2]+" juin "+myarr[0] ;
                }
                if( myarr[1] == "07"){
                  var dateN  = myarr[2]+" juillet "+myarr[0] ;
                }
                if( myarr[1] == "08"){
                  var dateN  = myarr[2]+" août "+myarr[0] ;
                }
                if( myarr[1] == "09"){
                  var dateN  = myarr[2]+" septembre "+myarr[0] ;
                }
                if( myarr[1] == "10"){
                  var dateN  = myarr[2]+" octobre "+myarr[0] ;
                }
                if( myarr[1] == "11"){
                  var dateN  = myarr[2]+" novembre "+myarr[0] ;
                }
                if( myarr[1] == "12"){
                  var dateN  = myarr[2]+" décembre "+myarr[0] ;
                }
           
                var dateFinal = dateN + " à " + heureReservedFinal ;


                const jsonData = [ { key: 'userId' , value: userId } , { key: 'listing_id' , value: listing_id }, { key: 'dateFinal' , value: dateFinal }, { key: 'phone' , value: phone }] ;


                Object.entries(localStorage).reverse().forEach(([key, value]) => {
                  if ( key.includes('collab_input_num_') ) {
                      if( $('[name=email]')[1].defaultValue !== '' && $('[name=phone]').val() !== '' ) {
                        // console.log('tsy videx' , key ,' => ' , value ) ;
                        var xx = {
                          "key_input_xx_key":key,
                          "value_input_xx_value":value
                        } ;
                        jsonData.push( xx ) ;
                      }else {
                        // console.log('videx', key ,' => ' , value ) ;
                      }
                  }
                }) ;
                
                var send = JSON.stringify(jsonData);
                
                // console.log('****', send) ;
                $.ajax({
                  type: "POST",
                  url:  "/wp-content/plugins/jm-collaborateur/Controller/bookingCollabData.php",
                  dataType: 'json',
                  data: 'dataBooking='+send ,
                  
                  success: function(data) {
                    // console.log('****---', data) ;
                  },
                });

              })
          }
          // ######## save Data collab Booking  ########
      
      // ####### JM MODIFE FIN ##########
      }) ;
      
  }

  function editCollab() {

    if (window.location.href.indexOf("action=edit") > -1) {

      

      // ### ajout editSave pour le bouton
      // $('[name=continue]').addClass('editSave') ; 
      $('[name=continue]').attr('id','editUpdate2');
 
      const url = window.location.href ;

      var listing_id = url.substring(url.lastIndexOf('=') + 1);

        $.ajax({
          type: "POST",
          url:  "/wp-content/plugins/jm-collaborateur/Controller/getData.php",
          dataType: 'json',
          data: { "listing_id": listing_id } ,
          
          success: function(data) {

            // console.log('xxxxxxxxx', data);

              $('#listing-overview').after('<form id="collabShow" style="padding:10px; box-shadow: 0px 1px 16px -2px grey ; border-radius: 10px;" ><h3 style="color:#73cdce;font-weight:bold !important;">Nos Collaborateurs</h3></form>');

              // console.log(data) ;
              data.forEach(element => {
                  // console.log(element['annonce_meta']) ;
                  var jsonCollab = JSON.parse(element['annonce_meta']) ;
                  
                  Object.entries(jsonCollab).forEach(([key, value]) => {
                      // console.log(key + ' - ' + value)
                      
                      if ( key.includes('collab_input_num_') ) {
                          var html = '<div id="newinput"><div id="row"> <div class="input-group m-3"><div class="input-group-prepend"><button class="btn btn-danger" id="DeleteRow" type="button"><i class="bi bi-trash"></i></button> </div><input type="text" class="form-control m-input collab_input" name="'+key+'" value="'+value+'" > </div> </div></div>' ;
                          $('#newinput').append(html) ;
                      }
                  })
              });


              // ######## update edit 
              $('#editUpdate2').on('click', function() {
              // $('.editSave').on('click', function(){
                // console.log('*****');

                var listing_id = $('[name=listing_id]').val() ;
                var colabData = $("#collabShow").serializeArray();
                colabData.push({ name: "listing_id", value: listing_id });
    
                $.ajax({
                  type: "POST",
                  url:  "/wp-content/plugins/jm-collaborateur/Controller/updateCollab.php",
                  dataType: 'json',
                  data: colabData ,
                  
                  success: function(data) {
                    // console.log('xxxxxxxxxxxxx', data) ;
                  },
      
                });

              })

          },

        });

        $('[name=edit_listing]').on('click', function(){
          localStorage.clear() ;
        })

    }
    else {
      // console.log('non') ;
    }

  }

  collab() ;
  editCollab() ;


} )
