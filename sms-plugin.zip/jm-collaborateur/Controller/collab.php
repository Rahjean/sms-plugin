<?php

define( 'SHORTINIT', true );
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

global $wpdb;

$table_name = $wpdb->prefix . 'sms_data_collaborateur_jm';

$meta = json_encode($_POST);
$listing_id = $_POST['listing_id'] ;

$wpdb->insert( $table_name , array(
   "id_annonce" => $listing_id,
   "annonce_meta" => $meta,
));

?>