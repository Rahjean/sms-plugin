<?php

define( 'SHORTINIT', true );
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

global $wpdb;
$table_name = $wpdb->prefix . 'sms_data_collaborateur_jm';
$id_annonce = $_POST['listing_id'] ;
$meta = json_encode($_POST);

$db = $wpdb->query(
    $wpdb->prepare( "UPDATE `$table_name` SET `annonce_meta`='$meta' WHERE `id_annonce`='$id_annonce' ")
) ;

if($db == 1 ) {
    $wpdb->flush();
}

?>