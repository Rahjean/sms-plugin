<?php

define( 'SHORTINIT', true );
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

global $wpdb;
$table_name = $wpdb->prefix . 'sms_data_collaborateur_jm';
$listing_id = $_POST['listing_id'] ;

$post_id = $wpdb->get_results(" SELECT `id_annonce`, `annonce_meta` FROM `$table_name` WHERE id_annonce=$listing_id ");

echo json_encode($post_id) ;

?>