<?php

define( 'SHORTINIT', true );
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

global $wpdb;
$table_name = $wpdb->prefix . 'sms_data_collaborateur_booking_jm';

$listing_id = trim(htmlspecialchars($_POST['listing_id']))  ;
$idUser = trim(htmlspecialchars($_POST['idUser']))  ;
$date       = trim(htmlspecialchars($_POST['date']))  ;
$phone      = trim(htmlspecialchars($_POST['phone']))  ;

// $getDataBooking = $wpdb->get_results(" SELECT * FROM `$table_name` WHERE id_annonce=$listing_id AND dateFinal=$date");
$getDataBooking = $wpdb->get_results(" SELECT * FROM `$table_name` WHERE id_annonce='$listing_id' AND id_user='$idUser' OR dateFinal='%$date%' AND phone LIKE '%$phone%' ");
echo json_encode($getDataBooking) ;

?>