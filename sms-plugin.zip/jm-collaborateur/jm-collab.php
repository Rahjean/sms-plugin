<?php
/*
Plugin Name: JM  Plugin Collaborateur
Plugin URI: https://mon-siteweb.com/
Description: JM  Plugin Collaborateur
Author: JM  Plugin Collaboratuer
Version: 1.0
Author URI: http://mon-siteweb.com/
*/


function collaborateur(){
	// create the custom table
	global $wpdb;
	
	$table_name = $wpdb->prefix . 'sms_data_collaborateur_jm';
	$charset_collate = $wpdb->get_charset_collate();
	
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        id_annonce longtext NOT NULL default '',
        annonce_meta longtext NOT NULL default '') $charset_collate;"
        ;
	
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
register_activation_hook( __FILE__, 'collaborateur' );


function roytuts_on_activation_booking(){
	// create the custom table
	global $wpdb;
	
	$table_name = $wpdb->prefix . 'sms_data_collaborateur_booking_jm';
	$charset_collate = $wpdb->get_charset_collate();
	
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        id_annonce longtext NOT NULL default '',
		id_user longtext NOT NULL default '',
		dateFinal longtext NOT NULL default '',
		phone longtext NOT NULL default '',
        booking_meta longtext NOT NULL default '') $charset_collate;"
        ;
	
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
register_activation_hook( __FILE__, 'roytuts_on_activation_booking' );

function custom_js_collab() {
    wp_enqueue_script( 'jquery_custom', plugins_url( '/Publics/lib/jquery.js', __FILE__) );
    wp_enqueue_script( 'my_custom_js', plugins_url( '/Controller/main.js', __FILE__ ) );
}
add_action('wp_enqueue_scripts','custom_js_collab');


function getPostId() {
	$current_user = wp_get_current_user();
	if ( 0 == $current_user->ID ) {
	    // var_dump($current_user->user_email) ;
	} else {
		session_start();
        // $phone = get_user_meta($current_user->ID,'phone',true);
		// $_SESSION['numeroPro'] = $phone ;
		// $_SESSION['mailPro']   = $current_user->user_email ;
		$_SESSION['userId'] = $current_user->ID ;
	}
	// $current_user = wp_get_current_user();
	// $_SESSION['userId'] = $current_user->ID ;
}
add_action( 'init', 'getPostId' );
