<?php

/* Template Name: Dashboard Sms rappel */

// define( 'SHORTINIT', true );
// require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

date_default_timezone_set('Europe/Paris');

get_header() ;

global $wpdb;

$table_name = $wpdb->prefix . 'sms_data_ovh_jm';
$results = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY id DESC");


?>



<div class="container-fluid" id="loadRappel" >
    <div class="row" >
      <h3>Date d'aujourd'hui 
          <?php 
              
              // setlocale(LC_TIME, "fr_FR", "French");
              // echo $datetime->format( 'H\hi' );

              $date1 = date('Y-m-d');
              setlocale(LC_TIME, "fr_FR","French");
              $date = strftime("%d %B %Y", strtotime($date1));
              echo $date ;

              $datetime = new DateTime( "now", new DateTimeZone( "Europe/Paris" ) );
              echo " " . $datetime->format( 'H\hi' );

          ?>
        </h3>
    </div>

    <div class="row" >
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Client</th>
            <th scope="col">Numero Pro</th>
            <th scope="col">Numero Client</th>
            <th scope="col">Mail Pro</th>
            <th scope="col">Mail Client</th>
            <th scope="col">Date création rendez-vous</th>
            <th scope="col">Date de rendez-vous</th>
            <th scope="col">Heure de rendez-vous</th>
            <th scope="col">Details</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($results as $row) { ?>
              <tr>
                  <td><?= $row->id ; ?></td>
                  <td><?= $row->clientName ; ?></td>
                  <td><?= $row->numeroPro ; ?></td>
                  <td><?= $row->numeroClient ; ?></td>
                  <td><?= $row->mailPro ; ?></td>
                  <td><?= $row->mailClient ; ?></td>
                  <td><?= $row->createDate ; ?></td>
                  <td><?= $row->reservedDate ; ?></td>
                  <td><?= $row->heureReserved ; ?></td>
                  <td><?= $row->details ; ?></td>
                  <td><?= $row->status ; ?></td>
              </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>

</div>