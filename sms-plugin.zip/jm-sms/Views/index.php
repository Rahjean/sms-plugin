<!-- <a href="#small-dialog" data-recipient="6" data-booking_id="booking_9" class="booking-message rate-review popup-with-zoom-anim"><i class="sl sl-icon-envelope-open"></i> Envoyer un sms</a>

<div id="small-dialog" class="zoom-anim-dialog mfp-hide">
     <div class="small-dialog-header">
          <h3>Envoyer un sms</h3>
     </div>
     <div class="message-reply margin-top-0">
          <form id="send-message-from-widget" data-booking_id="booking_9">
               <textarea data-recipient="" data-referral="" required="" cols="40" id="contact-message" name="message" rows="3" placeholder="Votre message"></textarea>
               <span id="sendSms">
                    <i class="fa fa-circle-o-notch fa-spin" aria-hidden="true"></i>
                    Envoyer un sms
               </span>
               <div class="notification closeable success margin-top-20" style="display: none;"></div>
          </form>
     </div>
</div> -->
<?php

     session_start();
     echo '<input type="hidden" id="numeroPro" value="'. $_SESSION['numeroPro'] .'">' ;
     echo '<input type="hidden" id="mailPro" value="'. $_SESSION['mailPro'] .'">' ;

?>

<!-- <span class="clickSms"> sms</span> -->