<?php

define( 'SHORTINIT', true );
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

require __DIR__ . '/vendor/autoload.php';
use \Ovh\Api;

date_default_timezone_set('Europe/Paris');

global $wpdb;

$table_name = $wpdb->prefix . 'sms_data_ovh_jm';
$results = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY id DESC");

$datetime = new DateTime( "now", new DateTimeZone( "Europe/Paris" ) );
$dateActuel = strtotime($datetime->format( 'Y-m-d H:i' )) ;
$heureActuel = $datetime->format( 'H:i' ) ;

echo 'heure Actuel:' .$heureActuel . '<br>' ;

$date_now = time(); //current timestamp

foreach ($results as $value) {
   $dateReserved    = strtotime($value->dateN); ;
   $heureReserved   = $value->heureReserved ;
   $status          = $value->status ;

   if( $status == 'En cours') {

        if( $date_now >= $dateReserved) {

            $dateDb  = $value->dateN ;
            $heureDb = $value->hoursN ;

            // $heureDbFormat = date('H:i', strtotime($heureDb)) ;


            // Une heure avant debut 

            // $time = '2022-11-29 00:00:00';
            // $time = strtotime($time) - 3600; 
            // $time = date(' Y-m-j H:i:s', $time);
            // echo strtotime($time) ;

            // $time = '2022-11-29 00:00:00';
            $timeBdHeureDate              = $dateDb .' ' . $heureDb .':00';
            $timeBdHeureDateMoin1H        = strtotime($timeBdHeureDate) - 3600; 
            $timeFinalMoin1H              = date(' Y-m-j H:i:s', $timeBdHeureDateMoin1H);
            echo '<br>une heure avant' . $timeFinalMoin1H;
            // Une heure avant fin 

            if ( $timeBdHeureDateMoin1H <= $dateActuel ) { // que l'heure est egal ou plus que l'heure de la base ( $time 1h avant l'heure de la base) 
                echo '<br>'. $timeBdHeureDate . ' => depasser ou egale' ;

                $smsId          = $value->id ;
                $clientName     = $value->clientName ;
                $numeroPro      = $value->numeroPro ;
                $numeroClient   = $value->numeroClient ;
                $reservedDate   = $value->reservedDate ;
                $heureReserved  = $value->heureReserved ;
                $details        = $value->details ;
            
                    $endpoint = 'ovh-eu';
                    $applicationKey = 'cf66f4da941f3c98';
                    $applicationSecret = '00e6bf2c8593531156f666097bd4d397';
                    $consumer_key = 'cedb2e2de6680efae011b1c1c88adc08';
                    
                    $conn  = new Ovh\Api($applicationKey, $applicationSecret, $endpoint, $consumer_key);
                    
                    $smsServices = $conn->get('/sms');
                    $contentClient = array();
                    $contentPro = array();
                    
                    foreach ($smsServices as $smsService) {
                        // print_r('vvvv' . $smsService);
                    }
                    
                    // ###### sms pour client debut ##########
                    $contentClient = (object) array(
                        "charset"=> "UTF-8",
                        "class"=> "phoneDisplay",
                        "coding"=> "7bit",
                        "message"=> "Bonjour,<br><br>********* Rappel rendez-vous pour client*********<br>Numéro du Pro: +". $numeroPro . "<br>Date de rendez-vous: " . $reservedDate . "<br>Heure de rendez-vous: " . $heureReserved . "<br>Details: " . $details  ,
                        "noStopClause"=> false,
                        "priority"=> "high",
                        "receivers"=> [ $numeroClient ],
                        "senderForResponse"=> true,
                        "validityPeriod"=> 2880
                    );
                    
                    $resultPostJobClient = $conn->post('/sms/'. $smsServices[0] . '/jobs', $contentClient);

                     ###### sms pour pro debut ##########
                     $contentPro = (object) array(
                        "charset"=> "UTF-8",
                        "class"=> "phoneDisplay",
                        "coding"=> "7bit",
                        "message"=> "Bonjour,<br><br>********* Rappel rendez-vous pour Pro*********<br>Nom du client: ". $clientName. "<br>Numero du client: +". $numeroClient . "<br>Date de rendez-vous: " . $reservedDate . "<br>Heure de rendez-vous: " . $heureReserved . "<br>Details: " . $details  ,
                        "noStopClause"=> false,
                        "priority"=> "high",
                        "receivers"=> [ $numeroPro ],
                        "senderForResponse"=> true,
                        "validityPeriod"=> 2880
                    );
                    
                    $resultPostJobPro = $conn->post('/sms/'. $smsServices[0] . '/jobs', $contentPro);
                    
                    // $smsJobs = $conn->get('/sms/'. $smsServices[0] . '/jobs');

                    $wpdb->query($wpdb->prepare("UPDATE $table_name SET status='Terminer' WHERE id=$smsId"));

            }else {
                echo '<br>'.$value->dateN .' ' . $value->hoursN .' => En cours 1' ;
            }
    
        }
        if( $date_now < $dateReserved) {
            echo '<br>'.$value->dateN .' ' . $value->hoursN .' => En cours 2' ;
        }
   }
   else {
        echo 'tsy en cours' ;
   }

}

?>