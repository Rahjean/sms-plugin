<?php
    define( 'SHORTINIT', true );
    require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

    require __DIR__ . '/vendor/autoload.php';
    use \Ovh\Api;

    global $wpdb;

        $endpoint = 'ovh-eu';
        $applicationKey = 'cf66f4da941f3c98';
        $applicationSecret = '00e6bf2c8593531156f666097bd4d397';
        $consumer_key = 'cedb2e2de6680efae011b1c1c88adc08';

        $createDate         = trim(htmlspecialchars($_POST['createDate'])) ;
        $clientName         = trim(htmlspecialchars($_POST['clientName'])) ;
        $reservedDate       = trim(htmlspecialchars($_POST['reservedDate'])) ;
        $numeroClient       = trim(htmlspecialchars($_POST['numeroClient'])) ;
        $numeroPro          = trim(htmlspecialchars($_POST['numeroPro'])) ;
        $mailPro            = trim(htmlspecialchars($_POST['mailPro'])) ;
        $mailClient         = trim(htmlspecialchars($_POST['mailClient'])) ;
        $heureReserved      = trim(htmlspecialchars($_POST['heureReserved'])) ;
        $dateN              = trim(htmlspecialchars($_POST['dateN'])) ;
        $details            = trim(htmlspecialchars($_POST['details'])) ;

        $hoursNPost         = trim(htmlspecialchars($_POST['heureReserved'])) ;
        $hoursN             = str_replace("h",":",$hoursNPost);
        
        $conn  = new Ovh\Api($applicationKey, $applicationSecret, $endpoint, $consumer_key);
        
        $smsServices = $conn->get('/sms');
        $content = array();

        $numClientFinal = '+'.$numeroClient ;
        $numProFinal    = '+'.$numeroPro;
        foreach ($smsServices as $smsService) {
            // print_r('vvvv' . $smsService);
        }
        
        $content = (object) array(
            "charset"=> "UTF-8",
            "class"=> "phoneDisplay",
            "coding"=> "7bit",
            "message"=> "Bonjour,<br>### Nouveau client ###<br>Nom: ". $clientName. "<br>Numéro Client: ".$numClientFinal .  "<br>Mail Client: " . $mailClient . "<br>Date de résèrvation: " . $reservedDate . " à " . $heureReserved . "<br>Details: " . $details  ,
            "noStopClause"=> false,
            "priority"=> "high",
            "receivers"=> [ $numProFinal ],
            "senderForResponse"=> true,
            "validityPeriod"=> 2880
        );
        
        $resultPostJob = $conn->post('/sms/'. $smsServices[0] . '/jobs', $content);
        var_dump($resultPostJob);
        
        $smsJobs = $conn->get('/sms/'. $smsServices[0] . '/jobs');


        // ####### insertion data sms 
        $table_name = $wpdb->prefix . 'sms_data_ovh_jm';
        $wpdb->insert( 
            $table_name, 
            array(
                'clientName' => $clientName ,
                'createDate' => $createDate,
                'reservedDate' => $reservedDate ,
                'numeroClient' => $numClientFinal,
                'numeroPro' => $numProFinal,
                'mailPro' => $mailPro, 
                'mailClient' => $mailClient,
                'heureReserved' => $heureReserved,
                'status' => 'En cours',
                'dateN' => $dateN,
                'hoursN' => $hoursN,
                'details' => $details, 
            ) 
        );




?>