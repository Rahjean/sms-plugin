$(document).ready(function() {
  console.log('oko 1');
  function smsConfirm() {

    console.log('oko 2');
      $.get( "/wp-content/plugins/jm-sms/Views/index.php", function( data ) {

        $( ".list-box-listing-content .inner" ).append( data );

        $('.approve').on('click', function(){
        // $('.clickSms').on('click', function(){

          var createDate      = $(this).closest(".waiting-booking").find("#price")[0].innerText ;
          var clientName      = $(this).closest(".waiting-booking").find("#name a")[0].innerText ;
          
          var numeroClient    = $(this).closest(".waiting-booking").find("#phone a")[0].innerText ;
          var numeroPro       = $('#numeroPro').val() ;
          var mailPro         = $('#mailPro').val() ;
          var mailClient      = $(this).closest(".waiting-booking").find("#email a")[0].innerText ;
          var details         = $(this).closest(".waiting-booking").find("#details")[0].innerText;

          var date = $(this).closest(".waiting-booking").find('#date')[0].outerText;
          var myarr = date.split(" ");
          var heureReserved = myarr.slice(-1)[0] ;
          var reservedDate  = myarr[0]+" "+myarr[1]+" "+myarr[2] ;

          if( myarr[1] == "janvier"){
            var dateN  = myarr[2]+"-01-"+myarr[0] ;
          }
          if( myarr[1] == "février"){
            var dateN  = myarr[2]+"-02-"+myarr[0] ;
          }
          if( myarr[1] == "mars"){
            var dateN  = myarr[2]+"-03-"+myarr[0] ;
          }
          if( myarr[1] == "avril"){
            var dateN  = myarr[2]+"-04-"+myarr[0] ;
          }
          if( myarr[1] == "mai"){
            var dateN  = myarr[2]+"-05-"+myarr[0] ;
          }
          if( myarr[1] == "juin"){
            var dateN  = myarr[2]+"-06-"+myarr[0] ;
          }
          if( myarr[1] == "juillet"){
            var dateN  = myarr[2]+"-07-"+myarr[0] ;
          }
          if( myarr[1] == "août"){
            var dateN  = myarr[2]+"-08-"+myarr[0] ;
          }
          if( myarr[1] == "septembre"){
            var dateN  = myarr[2]+"-09-"+myarr[0] ;
          }
          if( myarr[1] == "octobre"){
            var dateN  = myarr[2]+"-10-"+myarr[0] ;
          }
          if( myarr[1] == "novembre"){
            var dateN  = myarr[2]+"-11-"+myarr[0] ;
          }
          if( myarr[1] == "décembre"){
            var dateN  = myarr[2]+"-12-"+myarr[0] ;
          }
          

          var send = "createDate="+createDate+
                     "&clientName="+clientName+
                     "&reservedDate="+reservedDate+
                     "&numeroClient="+numeroClient+
                     "&numeroPro="+numeroPro+
                     "&mailPro="+mailPro+
                     "&mailClient="+mailClient+
                     "&heureReserved="+heureReserved+
                     "&dateN="+dateN+
                     "&details="+details ;


          console.log(send) ;

          $.ajax({
            type: "POST",
            url:  "/wp-content/plugins/jm-sms/Controller/sms.php",
            data: send ,
            
            success: function(data) {
              console.log(data) ;
            },

          });

        })

      });

  }

  // function loadSmsRappel() {
  //   console.log('okok loadSmsRappel');
  //     $('#smsRappel').on('click', function(){
  //         $.get( "/wp-content/plugins/jm-sms/Views/admin-rappel-sms.php", function( data ) {
  //               $( ".dashboard-content" ).empty() ;
  //               $( ".dashboard-content" ).append( data );
  //         })
  //     });

  // }

  smsConfirm() ;
  // loadSmsRappel() ;

} )
