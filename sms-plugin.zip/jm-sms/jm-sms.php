<?php
/*
Plugin Name: JM  Plugin SMS
Plugin URI: https://mon-siteweb.com/
Description: JM  Plugin SMS
Author: JM  Plugin SMS
Version: 1.0
Author URI: http://mon-siteweb.com/
*/

function roytuts_on_activation(){
	// create the custom table
	global $wpdb;
	
	$table_name = $wpdb->prefix . 'sms_data_ovh_jm';
	$charset_collate = $wpdb->get_charset_collate();
	
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        clientName varchar(200) NOT NULL default '',
        createDate varchar(200) NOT NULL default '',
        reservedDate varchar(200) NOT NULL default '',
        numeroPro varchar(200) NOT NULL default '',
        numeroClient varchar(200) NOT NULL default '',
        heureReserved varchar(200) NOT NULL default '',
        mailPro varchar(200) NOT NULL default '',
        mailClient varchar(200) NOT NULL default '',
        status varchar(200) NOT NULL default '',
        dateN varchar(200) NOT NULL default '',
        hoursN varchar(200) NOT NULL default '',
        details varchar(200) NOT NULL default '') $charset_collate;"
        ;
	
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}
register_activation_hook( __FILE__, 'roytuts_on_activation' );

function custom_js() {
    wp_enqueue_script( 'jquery_custom', plugins_url( '/Publics/lib/jquery.js', __FILE__) );
    wp_enqueue_script( 'my_custom_js_x', plugins_url( '/Controller/main.js', __FILE__ ) );
}
add_action('wp_enqueue_scripts','custom_js');




// ########### cron


// create a scheduled event (if it does not exist already)
function cronstarter_activation() {
	if( !wp_next_scheduled( 'ovh_sms_cron' ) ) {  
	   wp_schedule_event( time(), 'everyminute', 'ovh_sms_cron' );  
	}
}
// and make sure it's called whenever WordPress loads
add_action('wp', 'cronstarter_activation');

// here's the function we'd like to call with our cron job
function my_repeat_function_sms() {
	
	// do here what needs to be done automatically as per your schedule
	// in this example we're sending an email
	
	// components for our email
	// $recepients = 'webmaster.lunioncom@gmail.com';
	// $subject = 'Cron Sms ovh';
	// $message = 'Cron Sms ovh';
	
	// let's send it 
	// mail($recepients, $subject, $message);
    file_get_contents('https://mon-site.ga/wp-content/plugins/jm-sms/Controller/cron-sms.php') ;
}

// hook that function onto our scheduled event:
add_action ('ovh_sms_cron', 'my_repeat_function_sms'); 

// add custom interval
function cron_add_minute( $schedules ) {
	// Adds once every minute to the existing schedules.
    $schedules['everyminute'] = array(
	    'interval' => 60,
	    'display' => __( 'Once Every Minute' )
    );
    return $schedules;
}
add_filter( 'cron_schedules', 'cron_add_minute' );

// unschedule event upon plugin deactivation
function cronstarter_deactivate() {	
	// find out when the last event was scheduled
	$timestamp = wp_next_scheduled ('ovh_sms_cron');
	// unschedule previous event if any
	wp_unschedule_event ($timestamp, 'ovh_sms_cron');
} 
register_deactivation_hook (__FILE__, 'cronstarter_deactivate');

function wpdocs_check_logged_in() {
	$current_user = wp_get_current_user();
	if ( 0 == $current_user->ID ) {
	    // var_dump($current_user->user_email) ;
	} else {
		session_start();
        $phone = get_user_meta($current_user->ID,'phone',true);
		$_SESSION['numeroPro'] = $phone ;
		$_SESSION['mailPro']   = $current_user->user_email ;
	}
}
add_action( 'init', 'wpdocs_check_logged_in' );